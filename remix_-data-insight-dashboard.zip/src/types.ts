export interface SalesData {
  Date: string;
  Age_Group: string;
  Product_Category: string;
  Order_Quantity: number;
  Unit_Price: number;
  Revenue: number;
  parsedDate: Date;
}

export interface DashboardStats {
  totalRevenue: number;
  totalOrders: number;
  avgOrderValue: number;
  totalQuantity: number;
  revenueGrowth?: number;
}

export interface ChartDataPoint {
  name: string;
  value: number;
  [key: string]: any;
}
