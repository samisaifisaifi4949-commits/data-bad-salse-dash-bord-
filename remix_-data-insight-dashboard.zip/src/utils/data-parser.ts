import { SalesData } from '../types';
import { parse } from 'date-fns';

export function parseCSV(csv: string): SalesData[] {
  const lines = csv.trim().split('\n');
  const headers = lines[0].split(',');
  
  return lines.slice(1).map(line => {
    // Handle potential commas inside quotes
    const values: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') inQuotes = !inQuotes;
      else if (char === ',' && !inQuotes) {
        values.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    values.push(current.trim());

    const cleanNumeric = (val: string) => {
      return parseFloat(val.replace(/[$,"]/g, '').trim()) || 0;
    };

    const dateStr = values[0];
    // Try common date formats
    let parsedDate = new Date(dateStr);
    if (isNaN(parsedDate.getTime())) {
      parsedDate = parse(dateStr, 'M/d/yyyy', new Date());
    }

    return {
      Date: dateStr,
      Age_Group: values[1],
      Product_Category: values[2],
      Order_Quantity: cleanNumeric(values[3]),
      Unit_Price: cleanNumeric(values[4]),
      Revenue: cleanNumeric(values[5]),
      parsedDate
    };
  });
}

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0
  }).format(value);
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat('en-US').format(value);
}
